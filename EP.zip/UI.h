#ifndef __UI_H
#define __UI_H

#include <gtk/gtk.h>

void inicializa(int *argc, char *argv[]);

#endif /* __UI_H */