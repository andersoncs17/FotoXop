#ifndef __TESTES_H
#define __TESTES_H

void testeEtapa0();

void testeEtapa2();

void testeEtapa4();

void testeEtapa5();

#endif